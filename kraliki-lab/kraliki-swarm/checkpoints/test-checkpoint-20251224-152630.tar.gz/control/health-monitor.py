#!/usr/bin/env python3
"""
Health Monitor - Checks bot health endpoints and sends alerts
Runs as a cron job every 5 minutes
"""

import json
import subprocess
import urllib.request
from datetime import datetime
from pathlib import Path

import glob
import time

# Configuration - Kralici endpoints
HEALTH_ENDPOINTS = [
    {
        "name": "Kralici Dashboard",
        "url": "http://127.0.0.1:8099/health",
        "expected_status": 200
    }
]

KRALICI_DIR = Path("/home/adminmatej/github/ai-automation/kralici")
LOGS_DIR = KRALICI_DIR / "logs" / "agents"
ALERT_LOG = KRALICI_DIR / "logs" / "health-alerts.json"
STATUS_FILE = KRALICI_DIR / "control" / "health-status.json"
CIRCUIT_BREAKER_FILE = KRALICI_DIR / "control" / "circuit-breakers.json"

# API Error patterns
API_ERRORS = {
    "claude": ["You've hit your limit", "resets 5pm"],
    "codex": ["429 Too Many Requests", "usage_limit_reached"],
    "gemini": ["429 Too Many Requests", "Resource has been exhausted"]
}

# Agent prefix to CLI map
PREFIX_MAP = {
    "CC": "claude",
    "CX": "codex",
    "OC": "opencode",  # Often maps to Claude or specialized
    "GE": "gemini"
}


def log(msg: str, level: str = "INFO"):
    """Log with timestamp"""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] [{level}] {msg}")


def update_circuit_breaker(cli_tool: str, state: str, reason: str = None):
    """Update circuit breaker state."""
    breakers = {}
    if CIRCUIT_BREAKER_FILE.exists():
        try:
            breakers = json.loads(CIRCUIT_BREAKER_FILE.read_text())
        except Exception:
            pass

    key = f"{cli_tool}_cli"
    current = breakers.get(key, {"state": "closed"})
    
    # Only update if state changed
    if current.get("state") != state:
        current["state"] = state
        current["last_update"] = datetime.now().isoformat()
        if reason:
            current["last_failure_reason"] = reason
            log(f"Circuit breaker {state.upper()} for {cli_tool}: {reason}", "WARN")
        else:
            log(f"Circuit breaker {state.upper()} for {cli_tool}", "INFO")
            
        breakers[key] = current
        CIRCUIT_BREAKER_FILE.write_text(json.dumps(breakers, indent=2))


def check_agent_logs():
    """Scan recent agent logs for API errors."""
    try:
        # Check logs modified in the last 2 minutes
        recent_logs = []
        now = time.time()
        for log_file in LOGS_DIR.glob("*.log"):
            if now - log_file.stat().st_mtime < 120:
                recent_logs.append(log_file)
        
        for log_file in recent_logs:
            # Determine CLI from prefix
            prefix = log_file.name[:2]
            cli = PREFIX_MAP.get(prefix)
            
            # Map OC to claude for now as it uses Anthropic mostly
            if prefix == "OC":
                cli = "claude"
                
            if not cli:
                continue
                
            # Check for errors
            try:
                content = log_file.read_text()
                errors = API_ERRORS.get(cli, [])
                for error in errors:
                    if error in content:
                        update_circuit_breaker(cli, "open", f"Found '{error}' in {log_file.name}")
                        break
            except Exception:
                pass
                
    except Exception as e:
        log(f"Error checking logs: {e}", "ERROR")


def check_endpoint(endpoint: dict) -> dict:
    """Check a single endpoint"""
    result = {
        "name": endpoint["name"],
        "url": endpoint["url"],
        "timestamp": datetime.now().isoformat(),
        "status": "unknown",
        "error": None
    }

    try:
        req = urllib.request.Request(endpoint["url"], method="GET")
        with urllib.request.urlopen(req, timeout=10) as resp:
            result["status_code"] = resp.status
            if resp.status == endpoint["expected_status"]:
                result["status"] = "healthy"
            else:
                result["status"] = "degraded"
    except urllib.error.URLError as e:
        result["status"] = "down"
        result["error"] = str(e.reason)
    except Exception as e:
        result["status"] = "error"
        result["error"] = str(e)

    return result


def get_pm2_path() -> str:
    """Find the PM2 executable path"""
    # Common locations
    paths = [
        "/home/adminmatej/.nvm/versions/node/v22.14.0/bin/pm2",
        "/usr/local/bin/pm2",
        "/usr/bin/pm2"
    ]
    for p in paths:
        if Path(p).exists():
            return p
    return "pm2"  # Fallback to PATH


def check_pm2_processes() -> list:
    """Check PM2 process status"""
    pm2_path = get_pm2_path()
    try:
        # Explicitly set PM2_HOME to ensure we see the right processes in cron
        import os
        env = os.environ.copy()
        env["PM2_HOME"] = "/home/adminmatej/.pm2"
        
        result = subprocess.run(
            [pm2_path, "jlist"],
            capture_output=True,
            text=True,
            timeout=15,
            env=env
        )
        
        if not result.stdout or not result.stdout.strip():
            return [{"name": "pm2", "error": f"Empty output from pm2 jlist. Stderr: {result.stderr[:100]}"}]

        processes = json.loads(result.stdout)

        unhealthy = []
        for p in processes:
            status = p.get("pm2_env", {}).get("status", "unknown")
            if status != "online":
                unhealthy.append({
                    "name": p.get("name"),
                    "status": status,
                    "restarts": p.get("pm2_env", {}).get("restart_time", 0)
                })
        return unhealthy
    except Exception as e:
        return [{"name": "pm2", "error": str(e)}]


def send_alert(message: str):
    """Send alert (could integrate with Slack, Discord, etc.)"""
    # For now, log to file
    alerts = []
    if ALERT_LOG.exists():
        try:
            alerts = json.loads(ALERT_LOG.read_text())
        except:
            alerts = []

    alerts.append({
        "timestamp": datetime.now().isoformat(),
        "message": message
    })

    # Keep last 100 alerts
    alerts = alerts[-100:]
    ALERT_LOG.write_text(json.dumps(alerts, indent=2))

    log(f"ALERT: {message}", "ALERT")


def main():
    log("Starting health check...")

    all_healthy = True
    results = []

    # Check HTTP endpoints
    for endpoint in HEALTH_ENDPOINTS:
        result = check_endpoint(endpoint)
        results.append(result)

        if result["status"] != "healthy":
            all_healthy = False
            send_alert(f"{result['name']} is {result['status']}: {result.get('error', 'unknown error')}")
        else:
            log(f"{result['name']}: healthy")

    # Check PM2 processes
    unhealthy_procs = check_pm2_processes()
    if unhealthy_procs:
        all_healthy = False
        for proc in unhealthy_procs:
            send_alert(f"PM2 process {proc['name']} is {proc.get('status', 'unknown')}")
    else:
        log("PM2 processes: all healthy")

    # Check Agent Logs for API limits
    check_agent_logs()

    # Save status
    status = {
        "timestamp": datetime.now().isoformat(),
        "overall": "healthy" if all_healthy else "degraded",
        "endpoints": results,
        "pm2_issues": unhealthy_procs
    }
    STATUS_FILE.write_text(json.dumps(status, indent=2))

    log(f"Health check complete: {status['overall']}")


if __name__ == "__main__":
    import time
    CHECK_INTERVAL = 30  # seconds

    while True:
        try:
            main()
        except Exception as e:
            log(f"Error in health check: {e}", "ERROR")
        time.sleep(CHECK_INTERVAL)
